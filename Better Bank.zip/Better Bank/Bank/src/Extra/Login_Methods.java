package Extra;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Login_Methods {

    private static File statement;
    private static String user;
    private static String password;
    private static String balance;
    private static String address;

    //Sets the values when the class is called
    public Login_Methods(File statement) {
        this.statement = statement;
    }

    //gets the values of all the fields
    public static File getStatementFile() {
        return statement;
    }

    public static String getUser() {
        return user;
    }

    public static String getPassword() {
        return password;
    }

    public static String getBalance() {
        return balance;
    }

    public static String getAddress() {
        return address;
    }

    //sets the values of all the fields
    public static void setStatement(File statement) {
        Login_Methods.statement = statement;
    }

    public static void setUser(String user) {
        Login_Methods.user = user;
    }

    public static void setPassword(String password) {
        Login_Methods.password = password;
    }

    public static void setBalance(String balance) {
        Login_Methods.balance = balance;
    }

    public static void setAddress(String address) {
        Login_Methods.address = address;
    }

    //Read the statement file
    public static String getUserData(String fileName, File statement) {
        String username = "";
        String userPassword = "";

        try {
            BufferedReader br = new BufferedReader(new FileReader(statement));
            username = br.readLine();
            userPassword = br.readLine();
            br.close();
        } catch (Exception ex) {
            System.out.println("Error is: " + ex);
        }

        return username + "," + userPassword;
    }

    public static String getUserBalance(File statement) {
        String balance = "";

        try {
            BufferedReader br = new BufferedReader(new FileReader(statement));
            for (int i = 0; i < 7; i++) {
                br.readLine();
            }
            String[] balanceLine = br.readLine().split(" ");
            balance = balanceLine[5];
            br.close();
        } catch (IOException ex) {
            System.out.println("The error is: " + ex);
        }
        return balance;
    }

    public static String getStatement(File statement) {
        String statementData = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(statement));
            for (int i = 0; i < 3; i++) {
                br.readLine();
            }
            
            String line = br.readLine();
            
            while (line != null) {
                statementData += (line + "\n");
                line = br.readLine();
            }
            br.close();
        } catch (IOException ex) {
            System.out.println("The error is: " + ex);
        }
        return statementData;
    }
}
