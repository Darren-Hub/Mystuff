package access;
import java.io.*;

/**
 * @author Balancell
 */
public class Access2 {
    
  private static File Info;
  private static String UserNAME;
  private static String PassWord;
    
  public Access2 (File Info){
      Access2.Info = Info;
    }
  public static File getInfoFile(){
      return Info;
    }
  public static String getUserNAME(){
      return UserNAME;
    }
  public static String getPassWord(){
      return PassWord;
    }
  public static void setInfo(File Info){
      Access2.Info = Info;
    }
  public static void setUserNAME(String UserNAME){
      Access2.UserNAME = UserNAME;
    }
  public static void setPassWord(String PassWord){
      Access2.PassWord = PassWord;
    }
  
  public static String getUserInfo(String filename, File Info){
      String UsernamE = "";
      String PassworD = "";
      
      try{
          BufferedReader BR = new BufferedReader(new FileReader (Info));
          UsernamE = BR.readLine();
          PassworD = BR.readLine();
        }catch(IOException ex){
            System.out.println("Error" + ex);
        }
            return UsernamE + "," + PassworD; 
    }
  public static String getInfo(File Info){
      String InfoQ = "";
      try{
          BufferedReader Br = new BufferedReader(new FileReader(Info));
          
          for(int i = 0; i < 3; i++){
              Br.readLine();
          }
          String Line = Br.readLine();
          
          while (Line != null){
              InfoQ += (Line + "\n");
              Line = Br.readLine();
          }
      }catch(IOException ex){
          System.out.println("Error" + ex);
      }
      return InfoQ;
    }
    
}
