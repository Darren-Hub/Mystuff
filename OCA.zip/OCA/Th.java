package wed;

public class Wed
{
    public static void main(String[] args)
    {
       System.out.print("February 2019\n");
       System.out.print("Su Mo Tu We Th Fr Sa\n");
       System.out.print("               ");
       
       for(int i = 1; i < 29; i++)
       {
           if((i % 2 == 0 && i < 3) || (i % 9 == 0 && i < 10) || (i % 16 == 0 && i < 17) || i % 23 == 0)
               System.out.print(i + "\n");
           
           else
               if(i < 10)
                   System.out.print(i + "  ");
           
               else
                   System.out.print(i + " ");
       }
    } 
}
