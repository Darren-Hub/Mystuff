package balancell;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Balancell {

    private static File Container;
    private static String UserName;
    private static String Password;

public Balancell (File Container){
    this.Container = Container;
}

public static File getContainerFile(){
    return Container;
}

public static String getUserName(){
    return UserName;
}

public static String getPassword(){
    return Password;
}

public static void setContainer(File Container){
    Balancell.Container = Container;
}

public static void setUserName(String UserName){
    Balancell.UserName = UserName;
}

public static void setPassword(String Password){
    Balancell.Password = Password;
}

public static String getUserData(String fileName, File Container) {
        String UserName = "";
        String Password = "";
        
    try{
        BufferedReader Br = new BufferedReader(new FileReader(Container));
            UserName = Br.readLine();
            Password = Br.readLine();
            Br.close();
        } catch (Exception ex) {
            System.out.println("Error is: " + ex);
        }

        return UserName + "," + Password;
    }

 public static String getContainer(File Container) {
        String ContainerData = "";
        try {
            BufferedReader br = new BufferedReader(new FileReader(Container));
            for (int i = 0; i < 3; i++) {
                br.readLine();
            }
            
            String line = br.readLine();
            
            while (line != null) {
                ContainerData += (line + "\n");
                line = br.readLine();
            }
            br.close();
        } catch (IOException ex) {
            System.out.println("The error is: " + ex);
        }
        return ContainerData;
    }
}
